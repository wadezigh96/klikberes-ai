import {
  createTask, approveTask, executeTask, getTask, listTasks, resetTasks
} from "./task-engine.mjs";

export function resetApiState() {
  resetTasks();
}

export function handleApi(method, pathname, body = {}) {
  try {
    const path = new URL(pathname, "http://localhost").pathname;
    if (method === "GET" && path === "/api/health") {
      return { status: 200, body: { ok: true, app: "KlikBeres AI", version: "0.1.0" } };
    }
    if (method === "GET" && path === "/api/tasks") {
      return { status: 200, body: { tasks: listTasks() } };
    }
    if (method === "POST" && path === "/api/tasks") {
      return { status: 201, body: { task: createTask(body) } };
    }
    if (method === "POST" && path === "/api/demo/reset") {
      resetTasks();
      return { status: 200, body: { ok: true } };
    }
    const actionMatch = path.match(/^\/api\/tasks\/([a-zA-Z0-9_-]+)\/(approve|execute)$/);
    if (actionMatch && method === "POST") {
      const [, id, action] = actionMatch;
      const task = action === "approve" ? approveTask(id) : executeTask(id, body);
      return { status: 200, body: { task } };
    }
    const getMatch = path.match(/^\/api\/tasks\/([a-zA-Z0-9_-]+)$/);
    if (getMatch && method === "GET") {
      const task = getTask(getMatch[1]);
      return task
        ? { status: 200, body: { task } }
        : { status: 404, body: { error: { code: "NOT_FOUND", message: "Task not found." } } };
    }
    return { status: 404, body: { error: { code: "NOT_FOUND", message: "API route not found." } } };
  } catch (error) {
    const status = error.code === "NOT_FOUND" ? 404 : 422;
    return {
      status,
      body: { error: { code: error.code || "REQUEST_FAILED", message: error.message || "Request failed." } }
    };
  }
}
