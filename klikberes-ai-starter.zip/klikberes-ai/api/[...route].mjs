import { handleApi } from "../src/api-handler.mjs";

export default function handler(req, res) {
  const result = handleApi(req.method || "GET", req.url || "/", req.body || {});
  res.status(result.status).setHeader("Cache-Control", "no-store").json(result.body);
}
