import test, { beforeEach } from "node:test";
import assert from "node:assert/strict";
import handler from "../api/[...route].mjs";
import { resetApiState } from "../src/api-handler.mjs";

beforeEach(() => resetApiState());

function invoke(method, url, body = {}) {
  const response = {
    statusCode: 200,
    headers: {},
    status(code) { this.statusCode = code; return this; },
    setHeader(key, value) { this.headers[key] = value; return this; },
    json(payload) { this.payload = payload; return this; }
  };
  handler({ method, url, body }, response);
  return response;
}

test("Vercel function exposes health endpoint with no-store caching", () => {
  const response = invoke("GET", "/api/health");
  assert.equal(response.statusCode, 200);
  assert.equal(response.headers["Cache-Control"], "no-store");
  assert.equal(response.payload.app, "KlikBeres AI");
});

test("Vercel function enforces approval before local execution", () => {
  const created = invoke("POST", "/api/tasks", { title: "Fill demo form" });
  const id = created.payload.task.id;
  const blocked = invoke("POST", `/api/tasks/${id}/execute`, {
    fullName: "Test User", email: "test@example.com", purpose: "Demo"
  });
  assert.equal(blocked.statusCode, 422);
  const approved = invoke("POST", `/api/tasks/${id}/approve`);
  assert.equal(approved.payload.task.status, "approved");
});
