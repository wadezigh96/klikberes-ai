import test, { beforeEach } from "node:test";
import assert from "node:assert/strict";
import { handleApi, resetApiState } from "../src/api-handler.mjs";

beforeEach(() => resetApiState());

test("serves API health metadata", () => {
  const result = handleApi("GET", "/api/health");
  assert.equal(result.status, 200);
  assert.equal(result.body.ok, true);
});

test("creates and lists tasks through the API contract", () => {
  const created = handleApi("POST", "/api/tasks", { title: "Fill the demo form" });
  assert.equal(created.status, 201);
  assert.equal(created.body.task.status, "awaiting_approval");
  const listed = handleApi("GET", "/api/tasks");
  assert.equal(listed.body.tasks.length, 1);
});

test("enforces approval at the API boundary", () => {
  const { body: { task } } = handleApi("POST", "/api/tasks", { title: "Fill the demo form" });
  const attempted = handleApi("POST", `/api/tasks/${task.id}/execute`, {
    fullName: "Rani Example", email: "rani@example.com", purpose: "Demo"
  });
  assert.equal(attempted.status, 422);
  assert.match(attempted.body.error.message, /Approve the task/);
});

test("allows approved local execution and records safe evidence", () => {
  const { body: { task } } = handleApi("POST", "/api/tasks", { title: "Fill the demo form" });
  assert.equal(handleApi("POST", `/api/tasks/${task.id}/approve`, {}).body.task.status, "approved");
  const result = handleApi("POST", `/api/tasks/${task.id}/execute`, {
    fullName: "Rani Example", email: "rani@example.com", purpose: "Demo"
  });
  assert.equal(result.status, 200);
  assert.equal(result.body.task.evidence.submittedToExternalWebsite, false);
});

test("returns not found for unknown tasks and routes", () => {
  assert.equal(handleApi("GET", "/api/tasks/nope").status, 404);
  assert.equal(handleApi("GET", "/api/unknown").status, 404);
});
